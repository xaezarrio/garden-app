<div class="content-wrapper" >
      <!-- Main content -->
      <section class="content">
   		<div class="container">
		<div class="row no_margin">
			<h3 class="jdl_page">ADD TICKET</h3>
		</div>
        <div class="row">      
	        <div class="col-md-6">
	          <!-- general form elements -->
	          <div class="box box-primary">
	            <div class="box-header with-border">
	              <!-- <h3 class="box-title">New Tickets</h3> -->
					<b>Data Ticket</b>

	            </div>
	            <!-- /.box-header -->
	            <!-- form start -->
	            <form class="form-horizontal">
	              <div class="box-body">
	              	<table class="table table-bordered table-hover">
		            	<tr>
		            		<td style="width: 140px;">Title</td>
		            		<td><input type="text" class="form-control" placeholder="Title"></td>
		            	</tr>
		            	<tr>
		            		<td>Customer</td>
		            		<td>
		            			<select class="form-control select2">
			                      <option></option>
			                    </select>
		            		</td>
		            	</tr>
		            	<tr>
		            		<td>File</td>
		            		<td><input type="file" class="form-control" ></td>
		            	</tr>
		            	<tr>
		            		<td>Description</td>
		            		<td><textarea class="form-control" rows="4"></textarea></td>
		            	</tr>
		            </table>
	              </div>
	              <div class="box-footer">
	                <button type="submit" class="btn btn-primary">SAVE</button>
	              </div>
	          </form>

	          </div>
	          <!-- /.box -->

	        </div>
        <!--/.col (left) -->
        </div>
        <!-- /.box -->
   		</div>
      </section>
</div>