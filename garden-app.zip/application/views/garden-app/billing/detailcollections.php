<div class="content-wrapper" >
	<!-- Main content -->
	<section class="content">
		<div class="container">
			<div class="row no_margin">
				<h3 class="jdl_page">DETAIL PEMBAYARAN</h3>
			</div>
			<div class="row">
		                  <!-- left column -->
		        <div class="col-md-6">
		          <!-- general form elements -->
		          <div class="box box-primary">
		            <div class="box-header with-border">
		              <h3 class="box-title">Activity Metter 001</h3>
		            </div>
		            <div class="box-body">
		              <table class="table">
		                <thead>
		                  <tr>
		                    <th>Date</th>
		                    <th>Type</th>
		                    <th>Cost</th>
		                    <th>Activity</th>
		                  </tr>
		                </thead>
		              </table>
		              <hr>
		                <h5 >Remark CR:</h5>
		                <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
		                  Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles, weebly ning heekya handango imeem plugg
		                  dopplr jibjab, movity jajah plickers sifteo edmodo ifttt zimbra.
		                </p>
		            </div>
		          </div>
		          <!-- /.box -->

		        </div>
		        <div class="col-md-6">
		          <div class="box box-primary">
		            <div class="box-header with-border">
		              <h3 class="box-title"></h3>
		            </div>
		            <div class="box-body">
		              <div class="panel panel-default">
		                  <div class="panel-heading"><h5 class="panel-title">Proforma 001</h5></div>
		                  <div class="panel-body">
		                    <p>Date : 12 Jan 2018 <br>
		                    Nominal : 12.000.000,-</p>
		                  </div>
		              </div>
		              <div class="panel panel-default">
		                  <div class="panel-heading"><h5 class="panel-title">Invoice 001</h5></div>
		                  <div class="panel-body">
		                    <p>Date : 12 Jan 2018 <br>
		                    Nominal : 12.000.000,- <br>
		                    Remark : Nego Bayar 2x
		                  </p>
		                  </div>
		              </div>
		              <div class="panel panel-default">
		                  <div class="panel-heading"><h5 class="panel-title">Client</h5></div>
		                  <div class="panel-body">
		                  <p><strong>PT. ABCHJk</strong></p>
		                  <address>
		                    Batu, Malang  
		                  </address>
		                  </div>
		              </div>
		            </div>
		          </div>
		        </div>
			</div>
		</div>
	</section>
</div>