<div class="show_error"></div>
<input type="hidden" name="ids" value="<?= $costcenter['id'] ?>">
<small>Nama</small>
<input name="dt[name]" type="text" class="form-control" value="<?= $costcenter['name'] ?>" />