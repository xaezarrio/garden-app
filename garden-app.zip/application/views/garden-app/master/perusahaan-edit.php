<div class="show_error"></div>
<input type="hidden" name="ids" value="<?= $perusahaan['id'] ?>">
<small>Nama</small>
<input name="dt[name]" type="text" class="form-control" value="<?= $perusahaan['name'] ?>" />
<small>Alamat</small>
<input name="dt[address]" type="text" class="form-control" value="<?= $perusahaan['address'] ?>" />
<small>Telp</small>
<input name="dt[telp]" type="text" class="form-control" value="<?= $perusahaan['telp'] ?>" />